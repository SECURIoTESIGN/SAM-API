## Security Risk Analysis

Risk analysis based on database use and application environment of the cloud and mobile ecosystem

** High Security Risk **

