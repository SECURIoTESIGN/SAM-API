## Integrity                                 

Refers to the property which ensures that an IoT device or system is accessible and usable upon demand by authorized entities. In other words the device needs to be always available to access by authorized people. This requirement is applied in the Cloud. This requirement is applied in the database. This requirement is applied in the system.   