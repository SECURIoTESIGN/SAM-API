## Confidentiality

The property that ensures that information is not disclosed or made available to any unauthorized entity. In other words,personal information cannot be accessed by an unauthorized third party. This requirement is applied were the information is stored.
