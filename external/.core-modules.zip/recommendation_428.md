# Avoid Having a Domain Expire

To avoid ending up with an expired domain it is important to remember the domain expiration date.

## Manually

To consult your domain information you can go to https://lookup.icann.org/ insert your domain name, click on "Lookup" and the information regarding your domain will be showed. It is important to renew the domain before it expires!
A good way to never let your domain expire is by activating the automatic renewal function.